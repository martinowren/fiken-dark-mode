# Fiken darkmode

Dette er en veldig enkel chrome extension som gjør at du kan få Darkmode i fiken

Dette er et prosjekt som ble gjort pga mangel av oppdrag i Korona-tiden.
Gjerne vipps en liten sum som takk
93674399
